/**
 * Classe Abstrata Moeda: Base para todas as moedas do cofrinho.
 * Implementa o Encapsulamento (atributo private) e força o Polimorfismo
 * ao definir o método abstrato 'converterParaReal'.
 */
public abstract class Moeda {

    // Atributo encapsulado (private) para armazenar o valor da moeda
    private double valor;

    // Construtor
    public Moeda(double valor) {
        this.valor = valor;
    }

    // Método acessor (getter)
    public double getValor() {
        return valor;
    }

    // Método abstrato que DEVE ser implementado pelas subclasses.
    // É o ponto central do Polimorfismo por Subtipagem.
    public abstract double converterParaReal();

    // Método para exibir a informação da moeda (será sobrescrito nas subclasses)
    @Override
    public String toString() {
        return String.format("Valor: %.2f", valor);
    }
    
    // Métodos equals e hashCode são necessários para que a função removerMoeda
    // possa encontrar e remover objetos com o mesmo valor e tipo.
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Moeda moeda = (Moeda) o;
        return Double.compare(valor, moeda.valor) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(valor);
    }
}