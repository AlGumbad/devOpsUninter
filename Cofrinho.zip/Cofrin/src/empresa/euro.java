/**
 * Classe Euro: Herda de Moeda e implementa a lógica de conversão.
 */
public class Euro extends Moeda {

    // Simulação da taxa de câmbio (pode ser ajustada)
    private static final double TAXA_EURO = 6.00;

    public Euro(double valor) {
        super(valor);
    }

    // Polimorfismo: Implementação específica do método abstrato
    @Override
    public double converterParaReal() {
        return getValor() * TAXA_EURO;
    }

    // Sobrescrita do toString para identificação clara no console
    @Override
    public String toString() {
        return String.format("Euro - " + super.toString() + " | Equivalente em R$: %.2f", converterParaReal());
    }
    
    // Sobrescrevendo equals para considerar o tipo de moeda
    @Override
    public boolean equals(Object o) {
        return super.equals(o) && (o instanceof Euro);
    }
}