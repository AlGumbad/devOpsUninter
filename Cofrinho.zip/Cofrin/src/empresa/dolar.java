/**
 * Classe Dolar: Herda de Moeda e implementa a lógica de conversão.
 */
public class Dolar extends Moeda {

    // Simulação da taxa de câmbio (pode ser ajustada)
    private static final double TAXA_DOLAR = 5.00;

    public Dolar(double valor) {
        super(valor);
    }

    // Polimorfismo: Implementação específica do método abstrato
    @Override
    public double converterParaReal() {
        return getValor() * TAXA_DOLAR;
    }

    // Sobrescrita do toString para identificação clara no console
    @Override
    public String toString() {
        return String.format("Dólar - " + super.toString() + " | Equivalente em R$: %.2f", converterParaReal());
    }
    
    // Sobrescrevendo equals para considerar o tipo de moeda
    @Override
    public boolean equals(Object o) {
        return super.equals(o) && (o instanceof Dolar);
    }
}