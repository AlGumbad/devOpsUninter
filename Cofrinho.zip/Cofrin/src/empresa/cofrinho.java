import java.util.Scanner;

/**
 * Classe Principal: Contém o método main() e o menu de interação.
 */
public class Principal {

    private static Scanner scanner;
    private static Cofrinho cofrinho;

    public static void main(String[] args) {
        scanner = new Scanner(System.in);
        cofrinho = new Cofrinho();

        int opcao;
        
        // Loop principal para manter o menu ativo
        do {
            exibirMenu();
            // Tenta ler a opção do usuário
            if (scanner.hasNextInt()) {
                opcao = scanner.nextInt();
                scanner.nextLine(); // Consumir a nova linha
                executarOpcao(opcao);
            } else {
                System.out.println("\n❌ Entrada inválida. Por favor, digite um número.");
                scanner.nextLine(); // Limpar a entrada inválida
                opcao = 0; // Garante que o loop continue
            }
            
        } while (opcao != 4); // Opção 4 é para sair
        
        System.out.println("\n👋 Programa finalizado. Obrigado por usar o Cofrinho!");
        scanner.close();
    }

    private static void exibirMenu() {
        System.out.println("\n========= COFRINHO DE MOEDAS =========");
        System.out.println("| 1. Adicionar Moeda                 |");
        System.out.println("| 2. Remover Moeda                   |");
        System.out.println("| 3. Listar Moedas e Calcular Total  |");
        System.out.println("| 4. Sair                            |");
        System.out.println("======================================");
        System.out.print("Escolha uma opção: ");
    }

    private static void exibirMenuMoedas() {
        System.out.println("\n--- Tipos de Moeda ---");
        System.out.println("| 1. Dólar                           |");
        System.out.println("| 2. Euro                            |");
        System.out.println("| 3. Real                            |");
        System.out.println("----------------------");
        System.out.print("Escolha o tipo de moeda: ");
    }

    private static void executarOpcao(int opcao) {
        switch (opcao) {
            case 1:
                adicionarMoeda();
                break;
            case 2:
                removerMoeda();
                break;
            case 3:
                listarETotalizar();
                break;
            case 4:
                // Sai do loop no método main
                break;
            default:
                System.out.println("Opção inválida. Tente novamente.");
        }
    }
    
    private static void adicionarMoeda() {
        exibirMenuMoedas();
        int tipoMoeda;
        
        if (scanner.hasNextInt()) {
            tipoMoeda = scanner.nextInt();
            scanner.nextLine();
        } else {
            System.out.println("❌ Entrada inválida. Retornando ao menu principal.");
            scanner.nextLine();
            return;
        }

        System.out.print("Digite o valor da moeda (ex: 5.50): ");
        if (!scanner.hasNextDouble()) {
            System.out.println("❌ Valor inválido. Retornando ao menu principal.");
            scanner.nextLine();
            return;
        }
        
        double valor = scanner.nextDouble();
        scanner.nextLine();
        
        Moeda novaMoeda = null;
        
        // Polimorfismo: Instancia a classe correta com base na escolha do usuário
        switch (tipoMoeda) {
            case 1:
                novaMoeda = new Dolar(valor);
                break;
            case 2:
                novaMoeda = new Euro(valor);
                break;
            case 3:
                novaMoeda = new Real(valor);
                break;
            default:
                System.out.println("❌ Tipo de moeda inválido.");
                return;
        }
        
        cofrinho.adicionarMoeda(novaMoeda);
    }
    
    private static void removerMoeda() {
        exibirMenuMoedas();
        int tipoMoeda;
        
        if (scanner.hasNextInt()) {
            tipoMoeda = scanner.nextInt();
            scanner.nextLine();
        } else {
            System.out.println("❌ Entrada inválida. Retornando ao menu principal.");
            scanner.nextLine();
            return;
        }

        System.out.print("Digite o valor da moeda a ser removida (ex: 5.50): ");
        if (!scanner.hasNextDouble()) {
            System.out.println("❌ Valor inválido. Retornando ao menu principal.");
            scanner.nextLine();
            return;
        }
        
        double valor = scanner.nextDouble();
        scanner.nextLine();
        
        Moeda moedaParaRemover = null;

        // Cria uma instância temporária para usar o método equals()
        switch (tipoMoeda) {
            case 1:
                moedaParaRemover = new Dolar(valor);
                break;
            case 2:
                moedaParaRemover = new Euro(valor);
                break;
            case 3:
                moedaParaRemover = new Real(valor);
                break;
            default:
                System.out.println("❌ Tipo de moeda inválido.");
                return;
        }
        
        cofrinho.removerMoeda(moedaParaRemover);
    }
    
    private static void listarETotalizar() {
        cofrinho.listarMoedas();
        double total = cofrinho.calcularTotal();
        System.out.printf("💰 Total no Cofrinho (Convertido para R$): R$ %.2f\n", total);
    }
}}