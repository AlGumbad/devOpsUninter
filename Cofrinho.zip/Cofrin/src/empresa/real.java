/**
 * Classe Real: Herda de Moeda. A conversão é simples, pois o valor já está em Real.
 */
public class Real extends Moeda {

    public Real(double valor) {
        super(valor);
    }

    // Polimorfismo: Implementação específica do método abstrato
    @Override
    public double converterParaReal() {
        return getValor(); // Já está em Real
    }

    // Sobrescrita do toString para identificação clara no console
    @Override
    public String toString() {
        return String.format("Real - " + super.toString() + " | Equivalente em R$: %.2f", converterParaReal());
    }
    
    // Sobrescrevendo equals para considerar o tipo de moeda
    @Override
    public boolean equals(Object o) {
        return super.equals(o) && (o instanceof Real);
    }
}